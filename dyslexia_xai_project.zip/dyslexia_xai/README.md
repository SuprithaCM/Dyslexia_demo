# Explainable dyslexia analysis on EDTD70 (PPEI, LEPI, RFI, OPEI + nested LOPO + exact Shapley)

## Install (Windows / VS Code)
```
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```
## Where to put the files
Anywhere. Point the script at the dataset (the original `data_1_.zip` is read directly, nothing is extracted or modified) and the label CSV:
```
python run_pipeline.py --data C:\path\data_1_.zip --labels C:\path\dyslexia_class_label_1_.csv
```
Runtime is about 5-6 minutes on one CPU core (random forest dominates; use `--n-jobs -1` for more cores).
Tests: `python -m unittest discover -s tests -v`

## Output (all in `outputs/`)
`participant_index_results.csv` is the primary 7-column file (re-opened and validated after writing).
Also: lopo_predictions, participant_xai_explanations, global_index_importance, lopo_performance_metrics,
model_comparison, leakage_sensitivity, data_quality_report, index_correlations_spearman, lopo_fold_audit,
participant_raw_components, run_summary.txt, research_report.pdf, plots/, participant_reports/, trained_model/.
Open the CSV in Excel via Data > From Text/CSV (UTF-8, comma delimiter). OPEI is written with 6 decimals because its values are about 0.01.

## How it works
* Indices: formulas verbatim from your four documents; see `indices.py` and `outputs/run_summary.txt`.
* PPEI Z-scores (population SD) and LEPI min/max come from the 69 training participants of each fold only.
  The PPEI/LEPI/RFI/OPEI values in the CSV are exactly what the held-out fold's model received.
* Nested LOPO: 70 outer folds, inner 5-fold participant-grouped CV (ROC-AUC) for tuning; candidates
  LogisticRegression / RandomForest / SVM; selection criterion (out-of-fold ROC-AUC) fixed before comparison.
* XAI: exact interventional Shapley values on P(dyslexia) (all 16 coalitions enumerated, background = training
  participants of that fold, additivity checked for every participant). Positive = toward "Higher risk".
* Predicted result = held-out class at a fixed 0.5 threshold. "Main contributing index" = largest positive
  Shapley value, if at least 0.01 (1 percentage point); else "None identified". Not a biological cause.

## Assumptions you should confirm (not stated in the documents)
1. Participant level: AFD and SA averaged over the 3 tasks; progressive/regressive counts summed over tasks (RFI doc, Section 3); same aggregation reused for PPEI.
2. Word-level = AOI rows with aoi_kind == "subline". LEPI uses mean_fix_dur_aoi (mean, skipped words count as 0), n_revisits_aoi (sum), dwell_time_rereading_aoi (mean). PPEI rereading rate = sum n_revisits_aoi / sum n_fix_aoi on the same rows.
3. OPEI = mean over tasks of the per-trial OPE (raw, not normalised).
4. LEPI is not clipped to [0,1] for held-out participants.

## Known problem
The AFD constants of the RFI document reproduce exactly from this data, but the P/R and SA constants do not
(data give P/R ~5.09 SD 1.72, SA ~91.8 SD 14.1 vs documented 3.83/1.12 and 70.85/9.33). With the constants applied as written,
the RFI rule reproduces TN 34/FP 1/FN 12/TP 23, not the documented 29/6/3/32. The original P/R and SA computation is needed to resolve this.
Also, the RFI weights/threshold were fitted on all 70 labels, so RFI leaks label information into LOPO (see leakage_sensitivity.csv).

"""Run with:  python -m unittest discover -s tests -v      (pytest also works)"""
import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np, pandas as pd
import indices as ix
from xai import exact_shapley


def toy_comp():
    # three hand-made participants (values chosen so every result is checkable by hand)
    return pd.DataFrame({
        "n_readings": [3, 3, 3], "AFD": [400., 500., 600.], "SA": [70., 80., 90.],
        "n_fix": [100., 100., 100.], "n_progress": [60., 50., 40.], "n_regress": [10., 20., 30.],
        "OPE": [0.01, 0.02, 0.03], "word_n_fix": [100., 100., 100.], "word_revisits": [10., 20., 30.],
        "word_fix_dur": [1000., 1500., 2000.], "word_rereading": [100., 200., 300.]},
        index=pd.Index([1, 2, 3], name="sid"))


class TestFormulas(unittest.TestCase):
    def test_ope_trial(self):
        # 60 / (300 * (1 + 4)) = 0.04
        self.assertAlmostEqual(ix.ope_trial(60., 300., 4), 0.04)
        self.assertAlmostEqual(ix.ope_trial(60., 300., 0), 0.2)       # zero regressions: no division by zero

    def test_ppei_hand_calc(self):
        c = toy_comp(); ref = ix.ReferenceStats.fit(c)
        # components: prog rate .6,.5,.4 ; regr rate .1,.2,.3 ; rereading .1,.2,.3 ; AFD 400,500,600
        # population SD of 3 equally spaced values with step s is s*sqrt(2/3); z = (-1,0,1)/sqrt(2/3)
        z = 1 / np.sqrt(2 / 3)
        # participant 1: z(prog)=+z, z(regr)=-z, z(rerd)=-z, z(AFD)=-z  -> PPEI = z+z+z+z = 4z
        self.assertAlmostEqual(ix.compute_indices(c, ref).loc[1, "PPEI"], 4 * z, places=9)
        self.assertAlmostEqual(ix.compute_indices(c, ref).loc[2, "PPEI"], 0.0, places=9)

    def test_lepi_hand_calc(self):
        c = toy_comp(); ref = ix.ReferenceStats.fit(c)
        I = ix.compute_indices(c, ref)
        self.assertAlmostEqual(I.loc[1, "LEPI"], 0.0); self.assertAlmostEqual(I.loc[2, "LEPI"], 0.5)
        self.assertAlmostEqual(I.loc[3, "LEPI"], 1.0)

    def test_lepi_heldout_outside_training_range_not_clipped(self):
        c = toy_comp(); ref = ix.ReferenceStats.fit(c.iloc[:2])      # train on 2 participants only
        self.assertGreater(ix.compute_indices(c, ref).loc[3, "LEPI"], 1.0)

    def test_rfi_hand_calc(self):
        c = toy_comp(); c.loc[1, ["AFD", "SA"]] = [521.6570820744, 70.8453393787]
        c.loc[1, ["n_progress", "n_regress"]] = [3.8341603108 * 10, 10]      # P/R exactly at the reference mean
        v = ix.compute_indices(c, ix.ReferenceStats.fit(c)).loc[1, "RFI"]
        self.assertAlmostEqual(v, 0.3432131330, places=8)                      # all z = 0 -> intercept only
        c2 = c.copy(); c2.loc[1, "AFD"] += 112.6340793469                      # AFD_Z = +1
        v2 = ix.compute_indices(c2, ix.ReferenceStats.fit(c2)).loc[1, "RFI"]
        self.assertAlmostEqual(v2 - v, 1.7452431320, places=8)

    def test_zero_regressions_gives_nan_not_inf(self):
        c = toy_comp(); c.loc[1, "n_regress"] = 0
        self.assertTrue(np.isnan(ix.compute_indices(c, ix.ReferenceStats.fit(c)).loc[1, "RFI"]))

    def test_rfi_rules(self):
        self.assertEqual(ix.rfi_binary(-0.6923296350), "Dyslexic"); self.assertEqual(ix.rfi_binary(-0.7), "Non-dyslexic")
        self.assertEqual([ix.rfi_band(v) for v in (-1, 0, 1)], ["Low", "Medium", "High"])


class TestShapley(unittest.TestCase):
    def test_linear_model_exact(self):
        w = np.array([1., -2., 0.5, 3.]); f = lambda X: X @ w
        rng = np.random.default_rng(0); B = rng.normal(size=(50, 4)); x = rng.normal(size=4)
        phi, base, fx = exact_shapley(f, x, B)
        np.testing.assert_allclose(phi, w * (x - B.mean(0)), atol=1e-10)   # known closed form
        self.assertAlmostEqual(base + phi.sum(), fx)


class TestParticipantSeparation(unittest.TestCase):
    def test_lopo_folds(self):
        from run_pipeline import run_fold
        c = toy_comp().iloc[[0, 1, 2]]
        # participant-level rows: the held-out participant must never be in training
        import run_pipeline as rp
        ids = list(range(10)); rng = np.random.default_rng(1)
        comp = pd.DataFrame({k: rng.uniform(1, 2, 10) for k in toy_comp().columns}, index=pd.Index(ids, name="sid"))
        comp["n_readings"] = 3; comp["word_n_fix"] = comp.n_fix = 100.; comp["n_progress"] = 60.; comp["n_regress"] = rng.uniform(5, 30, 10)
        y = pd.Series([0, 1] * 5, index=ids)
        res = rp.run_lopo("LogisticRegression", ids, comp, y, ix.INDEX_NAMES, 1)
        self.assertEqual(sorted(r["held"] for r in res), ids)
        for r in res:
            self.assertNotIn(r["held"], r["train_ids"]); self.assertEqual(len(r["train_ids"]), 9)
            self.assertNotIn(r["held"], r["Xtr"].index)


if __name__ == "__main__":
    unittest.main()

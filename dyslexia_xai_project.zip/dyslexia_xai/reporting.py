"""Plots, participant reports and the combined PDF report."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import roc_curve

COL = {0: "#2b7bba", 1: "#d6604d"}
sns.set_theme(style="whitegrid", context="paper", font_scale=1.1)


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def make_all(out, table, comp, pred_df, xai_df, g, cmp_df, pm, ci, sm, idx_corr, labels, eligible, feats,
             fold, sel, runs, ps):
    out = Path(out)
    P = out / "plots"
    (P / "participant_shap").mkdir(parents=True, exist_ok=True)
    t = table.copy()
    t["Participant"] = t.Participant.astype(int)
    t["y"] = t.Participant.map(labels.y)
    t["group"] = t.y.map({0: "non-dyslexic", 1: "dyslexic"})
    t = t.sort_values(["y", "Participant"]).reset_index(drop=True)

    # 1 participant-wise comparison (original formula units)
    fig, ax = plt.subplots(4, 1, figsize=(15, 10), sharex=True)
    for a, k in zip(ax, feats):
        a.bar(range(len(t)), t[k].astype(float), color=[COL[v] for v in t.y])
        a.set_ylabel(k)
    ax[-1].set_xticks(range(len(t)))
    ax[-1].set_xticklabels(t.Participant, rotation=90, fontsize=7)
    ax[0].set_title("Participant-wise index values (original units; blue = non-dyslexic, red = dyslexic)")
    _save(fig, P / "01_participant_index_comparison.png")

    # 2 heatmap of standardised values
    Z = (t[feats].astype(float) - t[feats].astype(float).mean()) / t[feats].astype(float).std(ddof=0)
    fig, ax = plt.subplots(figsize=(6, 13))
    sns.heatmap(Z.set_index(t.Participant.astype(str)), cmap="vlag", center=0, ax=ax, cbar_kws={"label": "z-score across participants (NOT original units)"})
    ax.set_title("Index heatmap (standardised for display)\nrows sorted: non-dyslexic first, then dyslexic")
    _save(fig, P / "02_heatmap_indices_standardised.png")

    # 3 distributions
    fig, ax = plt.subplots(2, 2, figsize=(10, 7))
    for a, k in zip(ax.ravel(), feats):
        for v, name in [(0, "non-dyslexic"), (1, "dyslexic")]:
            sns.histplot(t.loc[t.y == v, k].astype(float), kde=True, ax=a, color=COL[v], label=name, alpha=0.45, stat="density")
        a.set_title(k)
        a.legend()
    _save(fig, P / "03_index_distributions.png")

    # 4 group comparison
    fig, ax = plt.subplots(1, 4, figsize=(13, 4))
    for a, k in zip(ax, feats):
        sns.boxplot(data=t.assign(v=t[k].astype(float)), x="group", y="v", hue="group", palette={"non-dyslexic": COL[0], "dyslexic": COL[1]}, ax=a, legend=False)
        sns.stripplot(data=t.assign(v=t[k].astype(float)), x="group", y="v", color="k", size=3, alpha=.5, ax=a)
        a.set_title(k); a.set_xlabel(""); a.set_ylabel("")
    _save(fig, P / "04_group_comparison.png")

    # 5 global importance
    gg = g.sort_values("mean_abs_shap")
    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    ax.barh(gg["index"], gg.mean_abs_shap, color="#555")
    for i, (m, s) in enumerate(zip(gg.mean_abs_shap, gg.mean_signed_shap)):
        ax.text(m, i, f"  mean signed {s:+.3f}", va="center", fontsize=8)
    ax.set_xlabel("mean |Shapley value| on P(dyslexia), held-out participants")
    ax.set_title(f"Global index importance ({sel})")
    ax.set_xlim(0, gg.mean_abs_shap.max() * 1.5)
    _save(fig, P / "05_global_importance.png")

    # 6 Shapley summary (direction + magnitude)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for i, k in enumerate(g.sort_values("mean_abs_shap")["index"]):
        v = xai_df[f"value_{k}"]
        vz = (v - v.min()) / (v.max() - v.min())
        ax.scatter(xai_df[f"phi_{k}"], i + np.random.default_rng(0).uniform(-.18, .18, len(v)), c=vz, cmap="coolwarm", s=18, edgecolor="none")
    ax.set_yticks(range(4)); ax.set_yticklabels(g.sort_values("mean_abs_shap")["index"])
    ax.axvline(0, color="k", lw=.8)
    ax.set_xlabel("Shapley value (positive = toward HIGHER predicted risk); colour = index value (blue low, red high)")
    ax.set_title("Participant-level contributions")
    _save(fig, P / "06_shap_summary.png")

    # 7 participant-specific plots
    for r in xai_df.itertuples():
        phi = pd.Series({k: getattr(r, f"phi_{k}") for k in feats}).sort_values()
        fig, ax = plt.subplots(figsize=(5.2, 2.8))
        ax.barh(phi.index, phi.values, color=["#d6604d" if v > 0 else "#2b7bba" for v in phi.values])
        ax.axvline(0, color="k", lw=.8)
        ax.set_title(f"Participant {r.Participant}: P(dyslexia)={r.predicted_p:.2f} (baseline {r.baseline_p:.2f})", fontsize=9)
        ax.set_xlabel("Shapley contribution (red = toward higher risk)")
        _save(fig, P / "participant_shap" / f"shap_{r.Participant}.png")

    # 8 model comparison
    fig, ax = plt.subplots(figsize=(6, 3.6))
    cm = cmp_df[["roc_auc", "accuracy"]]
    cm.plot.bar(ax=ax, rot=15)
    ax.set_ylim(0, 1); ax.set_title("Nested LOPO model comparison (held-out predictions)")
    _save(fig, P / "07_model_comparison.png")

    # 9 confusion matrix & ROC
    cmat = np.array([[pm["TN"], pm["FP"]], [pm["FN"], pm["TP"]]])
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    sns.heatmap(cmat, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=["Lower risk", "Higher risk"], yticklabels=["non-dyslexic", "dyslexic"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(f"LOPO confusion matrix ({sel})")
    _save(fig, P / "08_confusion_matrix.png")
    fpr, tpr, _ = roc_curve(pred_df.true_label, pred_df.p_dyslexia)
    fpr2, tpr2, _ = roc_curve(pred_df.true_label, ps)
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    ax.plot(fpr, tpr, label=f"4 indices (AUC {pm['roc_auc']:.3f})")
    ax.plot(fpr2, tpr2, "--", label=f"without RFI (AUC {sm['roc_auc']:.3f})")
    ax.plot([0, 1], [0, 1], ":k"); ax.set_xlabel("1 - specificity"); ax.set_ylabel("sensitivity"); ax.legend()
    ax.set_title("LOPO ROC")
    _save(fig, P / "09_roc_curve.png")

    # per-participant text reports
    rep = out / "participant_reports"
    x = xai_df.set_index("Participant")
    pr = pred_df.set_index("Participant")
    for s in eligible:
        r, p = x.loc[s], pr.loc[s]
        lines = [f"PARTICIPANT {s}", "=" * 40,
                 "INDEX VALUES (as received by the held-out fold model)",
                 *[f"  {k}: {r[f'value_{k}']:.6f}" for k in feats],
                 "", "MODEL PREDICTION (leave-one-participant-out; model never saw this participant)",
                 f"  P(dyslexia) = {p.p_dyslexia:.4f}  -> {p['Predicted result']}  (threshold 0.5, model: {p.model})",
                 f"  Reference label (not used in prediction): {p.true_label_text}",
                 "", "XAI - exact Shapley contributions to P(dyslexia)",
                 f"  baseline (mean predicted risk over 69 training participants) = {r.baseline_p:.4f}",
                 *[f"  {k}: {r[f'phi_{k}']:+.4f}" for k in feats],
                 f"  baseline + sum(contributions) = {r.baseline_p + sum(r[f'phi_{k}'] for k in feats):.4f} (= prediction {r.predicted_p:.4f})",
                 f"  toward higher risk: {r.toward_higher_risk}", f"  toward lower risk: {r.toward_lower_risk}",
                 f"  Main contributing index: {r.main_index}",
                 "", "FORMULA-BASED INTERPRETATION (separate evidence, from the supplied definitions)",
                 f"  RFI band: {r.formula_RFI_band}; RFI binary rule: {r.formula_RFI_binary}",
                 f"  LEPI band: {r.formula_LEPI_band}",
                 f"  OPEI cohort-normalised: {r.formula_OPEI_normalised_cohort:.3f} -> {r.formula_OPEI_efficiency_band}",
                 "  PPEI: no thresholds supplied; higher = more efficient reading.",
                 "", "CAUTION: contributions describe the model, not the biological cause of dyslexia. The indices are",
                 "correlated, so individual attributions can be unstable. RFI carries label information from all 70",
                 "participants (see run_summary.txt)."]
        (rep / f"participant_{s}.txt").write_text("\n".join(lines), encoding="utf-8")

    _pdf(out, P, table, g, cmp_df, pm, ci, sm, sel)


def _pdf(out, P, table, g, cmp_df, pm, ci, sm, sel):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    st = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(out / "research_report.pdf"), pagesize=A4, leftMargin=1.6 * cm, rightMargin=1.6 * cm)
    E = [Paragraph("Explainable dyslexia analysis on EDTD70: PPEI, LEPI, RFI, OPEI", st["Title"]),
         Paragraph(f"Nested leave-one-participant-out evaluation; selected model: <b>{sel}</b>; exact Shapley attribution.", st["Normal"]),
         Spacer(1, 8), Paragraph("Held-out performance (95% bootstrap CI)", st["Heading2"])]
    rows = [["Metric", "Value", "95% CI"]] + [[k, f"{pm[k]:.3f}", f"[{ci[k][0]:.3f}, {ci[k][1]:.3f}]"] for k in
                                            ["accuracy", "precision", "recall_sensitivity", "specificity", "f1", "roc_auc"]]
    def tbl(rows, w=None):
        t = Table(rows, colWidths=w)
        t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .3, colors.grey), ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                               ("FONTSIZE", (0, 0), (-1, -1), 8)]))
        return t
    E += [tbl(rows), Spacer(1, 6),
          Paragraph(f"Confusion matrix: TN={pm['TN']} FP={pm['FP']} FN={pm['FN']} TP={pm['TP']}. "
                    f"Sensitivity analysis without RFI (its weights were fitted on all 70 labels): accuracy {sm['accuracy']:.3f}, ROC-AUC {sm['roc_auc']:.3f}.", st["Normal"]),
          Spacer(1, 6), Paragraph("Global index ranking (mean |Shapley|)", st["Heading2"])]
    gr = g.sort_values("rank_by_mean_abs_shap")
    E.append(tbl([["Rank", "Index", "Mean |SHAP|", "Mean signed", "Main index (n)"]] +
                 [[int(r["rank_by_mean_abs_shap"]), r["index"], f"{r['mean_abs_shap']:.4f}", f"{r['mean_signed_shap']:+.4f}", int(r["n_times_main_index"])] for _, r in gr.iterrows()]))
    for f in ["05_global_importance.png", "08_confusion_matrix.png", "09_roc_curve.png", "07_model_comparison.png"]:
        E += [Spacer(1, 6), Image(str(P / f), width=11 * cm, height=11 * cm * (3.8 / 6.5) if "global" in f else 8 * cm, kind="proportional")]
    E += [PageBreak(), Paragraph("Participant table (primary output)", st["Heading2"])]
    rows = [list(table.columns)] + table.astype(str).values.tolist()
    rows = [[(c[:7] if len(c) > 7 and i in (1, 2, 3, 4) else c) for i, c in enumerate(r)] for r in rows]
    E.append(tbl(rows))
    E += [Spacer(1, 8), Paragraph("Limitations: 70 participants; exploratory research indices, not a clinical diagnostic; "
                                  "Shapley values describe the model, not the cause of dyslexia; indices are correlated; "
                                  "RFI constants carry label information from all participants.", st["Normal"])]
    doc.build(E)

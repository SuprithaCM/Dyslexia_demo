"""
Explainable dyslexia analysis on EDTD70: PPEI, LEPI, RFI, OPEI + nested LOPO CV + exact Shapley XAI.

Usage (Windows / VS Code terminal):
    python run_pipeline.py --data path\\to\\data_1_.zip --labels path\\to\\dyslexia_class_label.csv
Primary output: outputs/participant_index_results.csv
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, log_loss,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import GridSearchCV, StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

import indices as ix
from xai import explain_heldout

SEED = 42
DECISION_THRESHOLD = 0.5          # fixed a priori (balanced 35/35 classes, class_weight='balanced'); never tuned
MEANINGFUL_CONTRIB = 0.01         # min. positive Shapley value (= 1 percentage point of P(dyslexia)) to name a main index
SELECTION_CRITERION = "roc_auc"   # declared BEFORE model comparison; ties -> lower log-loss
DECIMALS = {"PPEI": 4, "LEPI": 4, "RFI": 4, "OPEI": 6}   # OPEI values are ~0.01, so 4 d.p. would discard information
OUT_COLS = ["Participant", "PPEI", "LEPI", "RFI", "OPEI", "Predicted result", "Main contributing index"]


# ---------------------------------------------------------------- models
def make_model(name: str):
    if name == "LogisticRegression":
        pipe = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler()),
                         ("clf", LogisticRegression(class_weight="balanced", max_iter=2000, random_state=SEED))])
        grid = {"clf__C": [0.01, 0.1, 1.0, 10.0]}
    elif name == "RandomForest":
        pipe = Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("clf", RandomForestClassifier(n_estimators=150, class_weight="balanced",
                                                        random_state=SEED, n_jobs=1))])
        grid = {"clf__max_depth": [3, None], "clf__min_samples_leaf": [1, 3]}
    elif name == "SVM":
        pipe = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler()),
                         ("clf", SVC(kernel="rbf", probability=True, class_weight="balanced", random_state=SEED))])
        grid = {"clf__C": [0.1, 1.0, 10.0]}
    else:
        raise ValueError(name)
    return pipe, grid


CANDIDATES = ["LogisticRegression", "RandomForest", "SVM"]


# ---------------------------------------------------------------- one LOPO fold
def run_fold(held, sids, comp, y, model_name, features):
    train_ids = [s for s in sids if s != held]
    assert held not in train_ids and len(train_ids) == len(sids) - 1
    ref = ix.ReferenceStats.fit(comp.loc[train_ids])          # reference stats: training participants only
    Xtr = ix.compute_indices(comp.loc[train_ids], ref)[features]
    Xte = ix.compute_indices(comp.loc[[held]], ref)[features]
    ytr = y.loc[train_ids]
    pipe, grid = make_model(model_name)
    inner = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)   # participant-grouped inner CV
    gs = GridSearchCV(pipe, grid, cv=inner, scoring="roc_auc", refit=True, n_jobs=1)
    gs.fit(Xtr, ytr, groups=np.array(train_ids))
    best = gs.best_estimator_
    pos = list(best.classes_).index(1)
    return dict(held=held, proba=float(best.predict_proba(Xte)[0, pos]), params=gs.best_params_,
                inner_auc=float(gs.best_score_), model=best, Xtr=Xtr, Xte=Xte, ref=ref, n_train=len(train_ids),
                train_ids=train_ids)


def run_lopo(model_name, sids, comp, y, features, n_jobs):
    res = Parallel(n_jobs=n_jobs)(delayed(run_fold)(s, sids, comp, y, model_name, features) for s in sids)
    held = [r["held"] for r in res]
    assert sorted(held) == sorted(sids) and len(set(held)) == len(sids), "each participant must be held out exactly once"
    return res


# ---------------------------------------------------------------- metrics
def metrics_from(y_true, proba, thr=DECISION_THRESHOLD):
    y_true = np.asarray(y_true); proba = np.asarray(proba)
    pred = (proba >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    out = dict(accuracy=accuracy_score(y_true, pred), precision=precision_score(y_true, pred, zero_division=0),
               recall_sensitivity=recall_score(y_true, pred, zero_division=0),
               specificity=tn / (tn + fp) if (tn + fp) else np.nan, f1=f1_score(y_true, pred, zero_division=0),
               roc_auc=roc_auc_score(y_true, proba) if len(set(y_true)) == 2 else np.nan,
               log_loss=log_loss(y_true, np.clip(proba, 1e-6, 1 - 1e-6), labels=[0, 1]),
               TN=tn, FP=fp, FN=fn, TP=tp, n=len(y_true))
    return out


def bootstrap_ci(y_true, proba, n_boot=2000, seed=SEED):
    """Participant-level percentile bootstrap (95%) of the held-out predictions."""
    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true); proba = np.asarray(proba)
    keys = ["accuracy", "precision", "recall_sensitivity", "specificity", "f1", "roc_auc"]
    vals = {k: [] for k in keys}
    for _ in range(n_boot):
        i = rng.integers(0, len(y_true), len(y_true))
        if len(set(y_true[i])) < 2:
            continue
        m = metrics_from(y_true[i], proba[i])
        for k in keys:
            vals[k].append(m[k])
    return {k: (np.nanpercentile(v, 2.5), np.nanpercentile(v, 97.5)) for k, v in vals.items()}


# ---------------------------------------------------------------- main-index rule
def main_index(phi: dict, ok: bool):
    """Index with the largest POSITIVE Shapley value (push toward higher risk) if >= MEANINGFUL_CONTRIB."""
    if not ok or any(not np.isfinite(v) for v in phi.values()):
        return "Inconclusive"
    name, val = max(phi.items(), key=lambda kv: kv[1])
    return name if val >= MEANINGFUL_CONTRIB else "None identified"


def fmt_csv(df):
    out = df.copy()
    for c, d in DECIMALS.items():
        out[c] = out[c].map(lambda v, d=d: "" if pd.isna(v) else f"{v:.{d}f}")
    return out


# ---------------------------------------------------------------- driver
def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="EDTD70 data folder or the data .zip")
    ap.add_argument("--labels", required=True, help="dyslexia_class_label CSV")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--n-jobs", type=int, default=-1)
    ap.add_argument("--n-boot", type=int, default=2000)
    a = ap.parse_args(argv)
    t0 = time.time()
    out = Path(a.out)
    for sub in ["", "plots", "participant_reports", "trained_model"]:
        (out / sub).mkdir(parents=True, exist_ok=True)

    # 1) load & inspect ------------------------------------------------------
    labels = ix.load_labels(a.labels)
    comp, issues = ix.build_components(ix.DataSource(a.data))
    data_ids, label_ids = set(comp.index), set(labels.index)
    dq = []
    for s in sorted(label_ids - data_ids):
        dq.append((s, "label present but no eye-tracking data", "excluded from table inputs"))
    for s in sorted(data_ids - label_ids):
        dq.append((s, "eye-tracking data present but no label", "indices computed; not LOPO-eligible"))
    for r in issues.itertuples():
        dq.append((r.participant, r.issue, r.file))
    all_ids = sorted(data_ids | label_ids)
    if not data_ids:
        raise RuntimeError("No participant data could be read.")

    # eligible = labelled, all 3 readings, all four indices computable
    ref_all = ix.ReferenceStats.fit(comp)       # ONLY used to decide completeness / descriptive displays
    idx_all = ix.compute_indices(comp, ref_all)
    complete = idx_all.notna().all(axis=1) & (comp.n_readings == comp.n_readings.max())
    eligible = sorted(s for s in comp.index if s in label_ids and complete[s])
    for s in comp.index:
        if not complete[s]:
            dq.append((s, f"incomplete data (readings={int(comp.n_readings[s])}, NaN index)", "excluded from LOPO"))
        for c in comp.columns:
            if pd.isna(comp.loc[s, c]):
                dq.append((s, f"missing component {c}", ""))
    y = labels.y
    if len(eligible) < 10 or y.loc[eligible].nunique() < 2:
        raise RuntimeError("Too few eligible participants / only one class: supervised LOPO cannot be validated.")
    print(f"Participants: data={len(data_ids)} labels={len(label_ids)} eligible={len(eligible)}  "
          f"class balance={y.loc[eligible].value_counts().to_dict()}")
    comp_e = comp.loc[eligible]
    feats = ix.INDEX_NAMES

    # 2) nested LOPO for each candidate -------------------------------------
    runs, comp_rows = {}, []
    for name in CANDIDATES:
        t1 = time.time()
        runs[name] = run_lopo(name, eligible, comp_e, y, feats, a.n_jobs)
        p = [r["proba"] for r in sorted(runs[name], key=lambda r: eligible.index(r["held"]))]
        m = metrics_from(y.loc[eligible], p)
        m.update(model=name, mean_inner_cv_auc=np.mean([r["inner_auc"] for r in runs[name]]))
        comp_rows.append(m)
        print(f"  {name:20s} AUC={m['roc_auc']:.3f} acc={m['accuracy']:.3f}  ({time.time()-t1:.0f}s)")
    cmp_df = pd.DataFrame(comp_rows).set_index("model")
    sel = cmp_df.sort_values(["roc_auc", "log_loss"], ascending=[False, True]).index[0]
    cmp_df["selected"] = cmp_df.index == sel
    cmp_df.to_csv(out / "model_comparison.csv")
    print(f"Selected model (criterion={SELECTION_CRITERION}, pre-declared): {sel}")

    fold = {r["held"]: r for r in runs[sel]}
    pred_df = pd.DataFrame({"Participant": eligible,
                            "true_label": [int(y[s]) for s in eligible],
                            "p_dyslexia": [fold[s]["proba"] for s in eligible]})
    pred_df["predicted_class"] = (pred_df.p_dyslexia >= DECISION_THRESHOLD).astype(int)
    pred_df["Predicted result"] = np.where(pred_df.predicted_class == 1, "Higher risk", "Lower risk")
    pred_df["true_label_text"] = np.where(pred_df.true_label == 1, "dyslexic", "non-dyslexic")
    pred_df["model"] = sel
    pred_df["best_params"] = [json.dumps(fold[s]["params"], default=str) for s in eligible]
    pred_df.to_csv(out / "lopo_predictions.csv", index=False)
    pd.DataFrame({"fold": range(1, len(eligible) + 1), "held_out_participant": eligible,
                  "n_train_participants": [fold[s]["n_train"] for s in eligible],
                  "held_out_in_train": [s in fold[s]["train_ids"] for s in eligible],
                  "best_params": [json.dumps(fold[s]["params"], default=str) for s in eligible],
                  "inner_cv_auc": [fold[s]["inner_auc"] for s in eligible]}).to_csv(out / "lopo_fold_audit.csv", index=False)

    # 3) performance + bootstrap CI -----------------------------------------
    pm = metrics_from(pred_df.true_label, pred_df.p_dyslexia)
    ci = bootstrap_ci(pred_df.true_label, pred_df.p_dyslexia, a.n_boot)
    rows = [dict(metric=k, value=pm[k], ci95_low=ci[k][0] if k in ci else np.nan,
                 ci95_high=ci[k][1] if k in ci else np.nan) for k in
            ["accuracy", "precision", "recall_sensitivity", "specificity", "f1", "roc_auc", "log_loss",
             "TN", "FP", "FN", "TP", "n"]]
    pd.DataFrame(rows).to_csv(out / "lopo_performance_metrics.csv", index=False)

    # 3b) sensitivity: RFI weights/threshold were fitted on all 70 labels -> rerun WITHOUT RFI
    sens_feats = [f for f in feats if f != "RFI"]
    sens = run_lopo(sel, eligible, comp_e, y, sens_feats, a.n_jobs)
    ps = [next(r["proba"] for r in sens if r["held"] == s) for s in eligible]
    sm = metrics_from(y.loc[eligible], ps)
    sm_ci = bootstrap_ci(y.loc[eligible], ps, a.n_boot)
    pd.DataFrame([dict(setting="all four indices (primary)", **{k: pm[k] for k in ["accuracy", "recall_sensitivity", "specificity", "f1", "roc_auc"]}),
                  dict(setting="PPEI+LEPI+OPEI (RFI removed; leakage sensitivity)", **{k: sm[k] for k in ["accuracy", "recall_sensitivity", "specificity", "f1", "roc_auc"]})]
                 ).to_csv(out / "leakage_sensitivity.csv", index=False)

    # 4) XAI with the fold-specific model ------------------------------------
    xai_rows = []
    for s in eligible:
        r = fold[s]
        pos = list(r["model"].classes_).index(1)
        phi, base, fx = explain_heldout(r["model"], r["Xtr"], r["Xte"], pos)
        add_err = abs(base + sum(phi.values()) - fx)
        ok = add_err < 1e-8 and abs(fx - r["proba"]) < 1e-8     # explanation is for THIS model's prediction
        order = sorted(phi, key=lambda k: -phi[k])
        xai_rows.append(dict(Participant=s, baseline_p=base, predicted_p=fx, additivity_error=add_err, explanation_valid=ok,
                             **{f"phi_{k}": phi[k] for k in feats},
                             **{f"value_{k}": float(r["Xte"][k].iloc[0]) for k in feats},
                             rank_toward_higher_risk=" > ".join(order),
                             toward_higher_risk=", ".join(k for k in order if phi[k] > 0) or "none",
                             toward_lower_risk=", ".join(k for k in order[::-1] if phi[k] < 0) or "none",
                             main_index=main_index(phi, ok)))
    xai_df = pd.DataFrame(xai_rows)
    # formula-based interpretation (separate evidence)
    fi = pd.DataFrame(index=eligible)
    lo, hi = comp_e.OPE.min(), comp_e.OPE.max()
    for s in eligible:
        v = {k: xai_df.set_index("Participant").loc[s, f"value_{k}"] for k in feats}
        fi.loc[s, "formula_RFI_binary"] = ix.rfi_binary(v["RFI"])
        fi.loc[s, "formula_RFI_band"] = ix.rfi_band(v["RFI"])
        fi.loc[s, "formula_LEPI_band"] = ix.three_band(v["LEPI"])
        fi.loc[s, "formula_OPEI_normalised_cohort"] = (v["OPEI"] - lo) / (hi - lo)
        fi.loc[s, "formula_OPEI_efficiency_band"] = {"Low": "Low efficiency (higher risk)", "Medium": "Medium efficiency",
                                                     "High": "High efficiency (lower risk)"}[ix.three_band(fi.loc[s, "formula_OPEI_normalised_cohort"])]
    xai_df = xai_df.merge(fi, left_on="Participant", right_index=True)
    xai_df.to_csv(out / "participant_xai_explanations.csv", index=False)

    g = pd.DataFrame({"index": feats,
                      "mean_abs_shap": [xai_df[f"phi_{k}"].abs().mean() for k in feats],
                      "mean_signed_shap": [xai_df[f"phi_{k}"].mean() for k in feats],
                      "share_of_participants_pushing_higher_risk": [(xai_df[f"phi_{k}"] > 0).mean() for k in feats],
                      "n_times_main_index": [(xai_df.main_index == k).sum() for k in feats]})
    g["rank_by_mean_abs_shap"] = g.mean_abs_shap.rank(ascending=False).astype(int)
    g.sort_values("rank_by_mean_abs_shap").to_csv(out / "global_index_importance.csv", index=False)

    # 5) final seven-column table -------------------------------------------
    # Index values shown = the exact values the held-out fold model received
    # (PPEI/LEPI reference statistics from the other 69 participants, as in PPEI.pdf).
    table = pd.DataFrame({"Participant": all_ids})
    vals = {k: {} for k in feats}
    for s in eligible:
        for k in feats:
            vals[k][s] = float(fold[s]["Xte"][k].iloc[0])
    for s in set(all_ids) - set(eligible):          # not LOPO-eligible: descriptive values from full-cohort reference
        for k in feats:
            vals[k][s] = float(idx_all.loc[s, k]) if s in idx_all.index else np.nan
    for k in feats:
        table[k] = table.Participant.map(vals[k])
    pr = pred_df.set_index("Participant")["Predicted result"]
    mi = xai_df.set_index("Participant")["main_index"]
    table["Predicted result"] = table.Participant.map(pr).fillna("Inconclusive")
    table["Main contributing index"] = table.Participant.map(mi).fillna("Inconclusive")
    table = table[OUT_COLS]
    path = out / "participant_index_results.csv"
    fmt_csv(table).to_csv(path, index=False, encoding="utf-8")

    # 6) validate the CSV after writing --------------------------------------
    chk = pd.read_csv(path, dtype={"Participant": str}, keep_default_na=False)
    assert list(chk.columns) == OUT_COLS, "CSV columns/order wrong"
    assert len(chk) == len(all_ids) and chk.Participant.is_unique, "row count / duplicates wrong"
    assert set(chk.Participant) == {str(s) for s in all_ids}, "participant IDs do not match dataset"
    for k in feats:
        a_ = pd.to_numeric(chk[k].replace("", np.nan))
        assert np.allclose(a_.to_numpy(float), table[k].to_numpy(float), atol=0.5 * 10 ** -DECIMALS[k], equal_nan=True), f"{k} mismatch"
    lp = pd.read_csv(out / "lopo_predictions.csv").set_index("Participant")["Predicted result"]
    assert all(chk.set_index(chk.Participant.astype(int))["Predicted result"].loc[eligible] == lp.loc[eligible]), "prediction mismatch"
    xp = pd.read_csv(out / "participant_xai_explanations.csv").set_index("Participant")["main_index"]
    assert all(chk.set_index(chk.Participant.astype(int))["Main contributing index"].loc[eligible] == xp.loc[eligible]), "main index mismatch"
    assert xai_df.explanation_valid.all(), "some explanations failed the additivity/consistency check"

    # 7) extra files ---------------------------------------------------------
    pd.DataFrame(dq, columns=["participant", "issue", "detail"]).to_csv(out / "data_quality_report.csv", index=False)
    comp.to_csv(out / "participant_raw_components.csv")
    idx_corr = table[feats].astype(float).corr(method="spearman")
    idx_corr.to_csv(out / "index_correlations_spearman.csv")

    final_ref = ix.ReferenceStats.fit(comp_e)
    Xall = ix.compute_indices(comp_e, final_ref)[feats]
    pipe, grid = make_model(sel)
    gs = GridSearchCV(pipe, grid, cv=StratifiedGroupKFold(5, shuffle=True, random_state=SEED), scoring="roc_auc")
    gs.fit(Xall, y.loc[eligible], groups=np.array(eligible))
    joblib.dump({"model": gs.best_estimator_, "reference_stats": final_ref, "features": feats,
                 "note": "Deployment artefact fitted on all eligible participants. NOT used for any reported prediction."},
                out / "trained_model" / "final_model.joblib")

    import reporting
    reporting.make_all(out, table, comp, pred_df, xai_df, g, cmp_df, pm, ci, sm, idx_corr, labels, eligible, feats,
                       fold, sel, runs, ps)

    ranked = g.sort_values("rank_by_mean_abs_shap")
    summ = [
        "RUN SUMMARY - Explainable dyslexia analysis (EDTD70)",
        f"Participants in data: {len(data_ids)}; labelled: {len(label_ids)}; LOPO-eligible: {len(eligible)}; in output table: {len(all_ids)}",
        f"Class balance (eligible): {y.loc[eligible].value_counts().rename({0:'non-dyslexic',1:'dyslexic'}).to_dict()}",
        "Positive class = dyslexia ('Higher risk'). Decision threshold fixed at 0.5 (not tuned, not calibrated).",
        "", "FORMULAS (verbatim from supplied documents)",
        "PPEI = Z(prog rate) - Z(regr rate) - Z(rereading rate) - Z(AFD); Z uses mean & population SD of the training participants of each fold",
        "LEPI = mean of min-max-normalised [word mean_fix_dur_aoi (mean), word n_revisits_aoi (sum), word dwell_time_rereading_aoi (mean)]; min/max from training participants of each fold; not clipped",
        f"RFI_Z = {ix.RFI_INTERCEPT} + {ix.RFI_W_AFD}*AFD_Z - {abs(ix.RFI_W_PR)}*PR_Z - {abs(ix.RFI_W_SA)}*SA_Z with the fixed ETDD70 constants of the RFI document",
        "OPEI = mean over readings of mean_sacc_ampl_trial / (mean_fix_dur_trial * (1 + n_regress_trial))  (raw, un-normalised value reported)",
        "Direction: higher PPEI = more efficient reading (lower risk); higher LEPI = more lexical difficulty; higher RFI = more dyslexia-like; higher OPEI = more efficient (lower risk).",
        "", "MODEL SELECTION",
        f"Nested LOPO ({len(eligible)} outer folds; inner 5-fold participant-grouped CV, criterion ROC-AUC). Candidates: {', '.join(CANDIDATES)}.",
        f"Selection criterion declared before comparison: out-of-fold {SELECTION_CRITERION} (ties: lower log-loss). Selected: {sel}.",
        cmp_df[["roc_auc", "accuracy", "log_loss"]].round(4).to_string(),
        "", "HELD-OUT PERFORMANCE (selected model, 95% participant-level bootstrap CI)",
        *[f"{k}: {pm[k]:.4f}  [{ci[k][0]:.3f}, {ci[k][1]:.3f}]" for k in ["accuracy", "precision", "recall_sensitivity", "specificity", "f1", "roc_auc"]],
        f"Confusion matrix: TN={pm['TN']} FP={pm['FP']} FN={pm['FN']} TP={pm['TP']}",
        "", "LEAKAGE SENSITIVITY",
        "The RFI coefficients, intercept and threshold were fitted by the document's authors on ALL 70 labelled participants, so RFI carries label information from every held-out participant. The primary results above are therefore optimistic. Re-running the same LOPO without RFI gives:",
        f"accuracy={sm['accuracy']:.4f} sensitivity={sm['recall_sensitivity']:.4f} specificity={sm['specificity']:.4f} ROC-AUC={sm['roc_auc']:.4f}",
        "", "GLOBAL XAI RANKING (mean |Shapley| on P(dyslexia))",
        ranked.round(4).to_string(index=False),
        "", "Spearman correlations between indices (attribution instability warning when |rho| is high):",
        idx_corr.round(3).to_string(),
        "", "LIMITATIONS",
        "- 70 independent participants: wide uncertainty; metrics are not external validation or clinical accuracy.",
        "- Model selection and reporting use the same outer predictions (small optimism).",
        "- Shapley values describe the model, not biological causes. Main contributing index = largest supported model contribution toward higher predicted risk, "
        f"requiring >= {MEANINGFUL_CONTRIB} (1 pp of probability); otherwise 'None identified'.",
        "- Correlated indices share attribution; individual attributions can be unstable.",
        "- Random-forest probabilities are not calibrated; no 'Inconclusive' probability band is used (no valid calibration), 'Inconclusive' only for missing/invalid results.",
        "- See README: the P/R and SA reference constants of the RFI document could not be reproduced from this dataset.",
    ]
    (out / "run_summary.txt").write_text("\n".join(summ), encoding="utf-8")
    print("\n".join(summ[-30:]))
    print(f"\nSUCCESS: validated CSV written to {path.resolve()}  ({time.time()-t0:.0f}s)")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:                                      # informative error, never claim success
        print(f"\nERROR: pipeline failed - no valid results were produced.\n  {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)

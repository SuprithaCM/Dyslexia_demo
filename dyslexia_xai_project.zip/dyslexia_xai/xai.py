"""
Exact Shapley-value attribution for a fitted model with few (here 4) features.

Method: interventional Shapley values of the model's P(dyslexia) output.
  v(S) = mean over background rows b of  f( x_S , b_notS )
  phi_j = sum_{S not containing j}  |S|!(d-|S|-1)!/d!  * ( v(S u {j}) - v(S) )
With d = 4 all 16 coalitions are enumerated, so the values are EXACT (no
sampling). The background is the fold's TRAINING participants only, so the
baseline E[f] is the model's mean predicted risk over the training cohort.
Efficiency holds: baseline + sum(phi) = f(x)  (checked for every participant).
Positive phi pushes the prediction toward the DYSLEXIA class (higher risk).
"""
from itertools import combinations
from math import factorial

import numpy as np
import pandas as pd


def exact_shapley(predict_fn, x: np.ndarray, background: np.ndarray):
    d = len(x)
    n = background.shape[0]
    masks = list(range(2 ** d))
    batch = []
    for m in masks:
        B = background.copy()
        for j in range(d):
            if m >> j & 1:
                B[:, j] = x[j]
        batch.append(B)
    preds = np.asarray(predict_fn(np.vstack(batch))).reshape(len(masks), n)
    v = preds.mean(axis=1)                       # v[mask]
    phi = np.zeros(d)
    for j in range(d):
        others = [k for k in range(d) if k != j]
        for r in range(d):
            w = factorial(r) * factorial(d - r - 1) / factorial(d)
            for S in combinations(others, r):
                m = sum(1 << k for k in S)
                phi[j] += w * (v[m | (1 << j)] - v[m])
    baseline = v[0]                              # E_background[f]
    fx = v[-1]                                   # f(x)
    return phi, baseline, fx


def explain_heldout(fitted_pipeline, X_train: pd.DataFrame, x_row: pd.DataFrame, pos_idx: int):
    """Explain one held-out participant with the fold-specific fitted model."""
    cols = list(X_train.columns)

    def f(arr):
        return fitted_pipeline.predict_proba(pd.DataFrame(arr, columns=cols))[:, pos_idx]

    phi, base, fx = exact_shapley(f, x_row[cols].to_numpy(float).ravel(), X_train.to_numpy(float))
    return dict(zip(cols, phi)), base, fx

"""
Data loading and the four reading indices (PPEI, LEPI, RFI, OPEI).

All formulas are taken verbatim from the supplied documents:
  PPEI.pdf, RFI_Standardized_Index.docx, lexical_issues.pdf, OPE.pdf, Formulas.docx

Participant-level aggregation (as stated in the RFI document, Section 3, and
used consistently for every index):
  * AFD  = mean of mean_fix_dur_trial over the participant's readings (tasks)
  * progressive / regressive counts are SUMMED over readings
  * SA   = mean of mean_sacc_ampl_trial over readings
Word-level (lexical) features use the AOI rows with aoi_kind == 'subline'
(= words), pooled over all of the participant's readings.
"""
from __future__ import annotations

import io
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

INDEX_NAMES = ["PPEI", "LEPI", "RFI", "OPEI"]

# ---- RFI constants, exactly as printed in RFI_Standardized_Index.docx -------
RFI_REF = {
    "AFD": (521.6570820744, 112.6340793469),   # (mean, SD)
    "PR": (3.8341603108, 1.1175387582),
    "SA": (70.8453393787, 9.3264616266),
}
RFI_INTERCEPT = 0.3432131330
RFI_W_AFD = 1.7452431320
RFI_W_PR = -1.2271234789
RFI_W_SA = -0.3877618524
RFI_BINARY_THRESHOLD = -0.6923296350        # RFI_Z >= threshold -> "Dyslexic"
RFI_BAND_CUT = 0.693147                     # Low < -cut <= Medium < +cut <= High

TRIAL_COLS = ["n_fix_trial", "mean_fix_dur_trial", "mean_sacc_ampl_trial",
              "n_progress_trial", "n_regress_trial"]
WORD_COLS = ["mean_fix_dur_aoi", "n_fix_aoi", "n_revisits_aoi",
             "dwell_time_rereading_aoi"]


# --------------------------------------------------------------------------
# Data access (folder OR zip file, never modifies the original data)
# --------------------------------------------------------------------------
class DataSource:
    """Reads *_metrics.csv files from a directory or directly from a .zip."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        if not self.path.exists():
            raise FileNotFoundError(f"Data path not found: {self.path}")
        self._zip = None
        if self.path.is_file():
            if self.path.suffix.lower() != ".zip":
                raise ValueError(f"Unsupported data file type: {self.path.suffix} (use a folder or .zip)")
            self._zip = zipfile.ZipFile(self.path)
            names = [n for n in self._zip.namelist() if not n.startswith("__MACOSX")]
        else:
            names = [str(p) for p in self.path.rglob("*") if p.is_file()]
        self.metrics_files = sorted(n for n in names if n.endswith("_metrics.csv")
                                    and re.search(r"Subject_\d+_", n))
        if not self.metrics_files:
            raise FileNotFoundError(f"No Subject_*_metrics.csv files found in {self.path}")

    def read(self, name: str) -> pd.DataFrame:
        if self._zip is not None:
            with self._zip.open(name) as fh:
                return pd.read_csv(io.BytesIO(fh.read()))
        return pd.read_csv(name)


def load_labels(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Label file not found: {path}")
    lab = pd.read_csv(path)
    missing = {"subject_id", "class_id", "label"} - set(lab.columns)
    if missing:
        raise ValueError(f"Label file is missing columns: {sorted(missing)}")
    if lab.subject_id.duplicated().any():
        raise ValueError("Duplicate subject_id values in label file")
    # consistency of class_id <-> label text
    pairs = lab.groupby("class_id").label.nunique()
    if (pairs > 1).any():
        raise ValueError("Inconsistent class_id/label pairs in label file")
    lab["y"] = (lab.label.str.lower().str.strip() == "dyslexic").astype(int)
    if not (lab.y == lab.class_id).all():
        raise ValueError("class_id does not agree with label text (dyslexic must be 1)")
    return lab.set_index("subject_id")


# --------------------------------------------------------------------------
# Participant-level raw components
# --------------------------------------------------------------------------
def ope_trial(mean_sacc_ampl, mean_fix_dur, n_regress):
    """OPE = mean_sacc_ampl_trial / (mean_fix_dur_trial * (1 + n_regress_trial))."""
    return mean_sacc_ampl / (mean_fix_dur * (1.0 + n_regress))


def build_components(source: DataSource) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (components per participant, data-quality issue log)."""
    trial_rows, word_rows, issues = [], [], []
    for f in source.metrics_files:
        m = source.read(f)
        sid = int(re.search(r"Subject_(\d+)_", f).group(1))
        need = set(TRIAL_COLS + WORD_COLS + ["trialid", "aoi_kind", "task"])
        if need - set(m.columns):
            issues.append((sid, f, f"missing columns {sorted(need - set(m.columns))}"))
            continue
        if (m.sid != sid).any():
            issues.append((sid, f, "sid column disagrees with file name"))
        task = m.task.iloc[0]
        trials = m.drop_duplicates(["trialid"]).copy()          # trial-level cols repeat per AOI row
        if trials[TRIAL_COLS].isna().any().any():
            issues.append((sid, f, "NaN in trial-level columns (rows with NaN dropped)"))
            trials = trials.dropna(subset=TRIAL_COLS)
        trials["task"] = task
        trials["sid"] = sid
        trials["ope"] = ope_trial(trials.mean_sacc_ampl_trial, trials.mean_fix_dur_trial, trials.n_regress_trial)
        bad = ~np.isfinite(trials.ope)
        if bad.any():
            issues.append((sid, f, f"{int(bad.sum())} trial(s) with non-finite OPE dropped"))
            trials = trials[~bad]
        trial_rows.append(trials[["sid", "task", "trialid"] + TRIAL_COLS + ["ope"]])
        w = m[m.aoi_kind == "subline"].copy()
        w["sid"], w["task"] = sid, task
        word_rows.append(w[["sid", "task"] + WORD_COLS])
        if m.duplicated().any():
            issues.append((sid, f, f"{int(m.duplicated().sum())} fully duplicated rows"))
    T = pd.concat(trial_rows, ignore_index=True)
    W = pd.concat(word_rows, ignore_index=True)

    comp = pd.DataFrame(index=sorted(T.sid.unique()))
    comp.index.name = "sid"
    g = T.groupby("sid")
    comp["n_readings"] = g.task.nunique()
    comp["AFD"] = g.mean_fix_dur_trial.mean()
    comp["SA"] = g.mean_sacc_ampl_trial.mean()
    comp["n_fix"] = g.n_fix_trial.sum()
    comp["n_progress"] = g.n_progress_trial.sum()
    comp["n_regress"] = g.n_regress_trial.sum()
    comp["OPE"] = g.ope.mean()                                  # OPE_Task = mean(OPE) by (sid, task); then mean over tasks
    for t, sub in T.groupby("task"):
        comp[f"OPE_{t}"] = sub.groupby("sid").ope.mean()
    gw = W.groupby("sid")
    comp["word_n_fix"] = gw.n_fix_aoi.sum()
    comp["word_revisits"] = gw.n_revisits_aoi.sum()             # sum for revisits (lexical_issues.pdf)
    comp["word_fix_dur"] = gw.mean_fix_dur_aoi.mean()           # mean for fixation
    comp["word_rereading"] = gw.dwell_time_rereading_aoi.mean() # mean for rereading
    return comp, pd.DataFrame(issues, columns=["participant", "file", "issue"])


# --------------------------------------------------------------------------
# Reference statistics (learned from TRAINING participants only)
# --------------------------------------------------------------------------
def ppei_components(comp: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "prog_rate": comp.n_progress / comp.n_fix,
        "regr_rate": comp.n_regress / comp.n_fix,
        "rereading_rate": comp.word_revisits / comp.word_n_fix,    # n_revisits_aoi / n_fix_aoi
        "AFD": comp.AFD,
    })


@dataclass
class ReferenceStats:
    ppei_mean: pd.Series
    ppei_sd: pd.Series          # population SD (divide by N), as in PPEI.pdf
    lepi_min: pd.Series
    lepi_max: pd.Series

    @classmethod
    def fit(cls, train_comp: pd.DataFrame) -> "ReferenceStats":
        pc = ppei_components(train_comp)
        lc = train_comp[["word_fix_dur", "word_revisits", "word_rereading"]]
        return cls(pc.mean(), pc.std(ddof=0), lc.min(), lc.max())


def compute_indices(comp: pd.DataFrame, ref: ReferenceStats) -> pd.DataFrame:
    """PPEI, LEPI, RFI, OPEI for every row of `comp` using fixed reference stats."""
    pc = ppei_components(comp)
    sd = ref.ppei_sd.replace(0, np.nan)
    z = (pc - ref.ppei_mean) / sd
    ppei = z.prog_rate - z.regr_rate - z.rereading_rate - z.AFD

    lc = comp[["word_fix_dur", "word_revisits", "word_rereading"]]
    rng = (ref.lepi_max - ref.lepi_min).replace(0, np.nan)
    lepi = ((lc - ref.lepi_min) / rng).mean(axis=1, skipna=False)   # not clipped: held-out may fall outside [0,1]

    pr = comp.n_progress / comp.n_regress.replace(0, np.nan)        # P/R = sum progressive / sum regressive
    afd_z = (comp.AFD - RFI_REF["AFD"][0]) / RFI_REF["AFD"][1]
    pr_z = (pr - RFI_REF["PR"][0]) / RFI_REF["PR"][1]
    sa_z = (comp.SA - RFI_REF["SA"][0]) / RFI_REF["SA"][1]
    rfi = RFI_INTERCEPT + RFI_W_AFD * afd_z + RFI_W_PR * pr_z + RFI_W_SA * sa_z

    return pd.DataFrame({"PPEI": ppei, "LEPI": lepi, "RFI": rfi, "OPEI": comp.OPE}, index=comp.index)


# --------------------------------------------------------------------------
# Formula-based interpretation (separate evidence from the ML explanation)
# --------------------------------------------------------------------------
def rfi_binary(rfi: float) -> str:
    if not np.isfinite(rfi):
        return "n/a"
    return "Dyslexic" if rfi >= RFI_BINARY_THRESHOLD else "Non-dyslexic"


def rfi_band(rfi: float) -> str:
    if not np.isfinite(rfi):
        return "n/a"
    if rfi < -RFI_BAND_CUT:
        return "Low"
    return "Medium" if rfi < RFI_BAND_CUT else "High"


def three_band(x: float) -> str:
    """Low/Medium/High per the supplied 0-0.33 / 0.34-0.66 / 0.67-1.00 ranges
    (the unspecified gaps 0.33-0.34 and 0.66-0.67 are assigned to the lower band)."""
    if not np.isfinite(x):
        return "n/a"
    return "Low" if x < 0.34 else ("Medium" if x < 0.67 else "High")
